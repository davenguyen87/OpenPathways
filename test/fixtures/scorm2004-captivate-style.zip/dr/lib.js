// Captivate runtime
window.cp = {
    isPlayer: true,
    version: '2023.1'
};
function playSlide() { console.log('Playing slide'); }
