// SWFObject (legacy Flash detection)
var swfobject = { hasFlashPlayerVersion: function() { return false; } };
